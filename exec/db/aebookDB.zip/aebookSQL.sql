-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema s08p31c201
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema s08p31c201
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `s08p31c201` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ;
USE `s08p31c201` ;

-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_instance`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_instance` (
  `JOB_INSTANCE_ID` BIGINT(20) NOT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `JOB_NAME` VARCHAR(100) NOT NULL,
  `JOB_KEY` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`JOB_INSTANCE_ID`),
  UNIQUE INDEX `JOB_INST_UN` (`JOB_NAME` ASC, `JOB_KEY` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_execution`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_execution` (
  `JOB_EXECUTION_ID` BIGINT(20) NOT NULL,
  `VERSION` BIGINT(20) NULL DEFAULT NULL,
  `JOB_INSTANCE_ID` BIGINT(20) NOT NULL,
  `CREATE_TIME` DATETIME NOT NULL,
  `START_TIME` DATETIME NULL DEFAULT NULL,
  `END_TIME` DATETIME NULL DEFAULT NULL,
  `STATUS` VARCHAR(10) NULL DEFAULT NULL,
  `EXIT_CODE` VARCHAR(2500) NULL DEFAULT NULL,
  `EXIT_MESSAGE` VARCHAR(2500) NULL DEFAULT NULL,
  `LAST_UPDATED` DATETIME NULL DEFAULT NULL,
  `JOB_CONFIGURATION_LOCATION` VARCHAR(2500) NULL DEFAULT NULL,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  INDEX `JOB_INST_EXEC_FK` (`JOB_INSTANCE_ID` ASC) VISIBLE,
  CONSTRAINT `JOB_INST_EXEC_FK`
    FOREIGN KEY (`JOB_INSTANCE_ID`)
    REFERENCES `s08p31c201`.`batch_job_instance` (`JOB_INSTANCE_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_execution_context`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_execution_context` (
  `JOB_EXECUTION_ID` BIGINT(20) NOT NULL,
  `SHORT_CONTEXT` VARCHAR(2500) NOT NULL,
  `SERIALIZED_CONTEXT` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_CTX_FK`
    FOREIGN KEY (`JOB_EXECUTION_ID`)
    REFERENCES `s08p31c201`.`batch_job_execution` (`JOB_EXECUTION_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_execution_params`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_execution_params` (
  `JOB_EXECUTION_ID` BIGINT(20) NOT NULL,
  `TYPE_CD` VARCHAR(6) NOT NULL,
  `KEY_NAME` VARCHAR(100) NOT NULL,
  `STRING_VAL` VARCHAR(250) NULL DEFAULT NULL,
  `DATE_VAL` DATETIME NULL DEFAULT NULL,
  `LONG_VAL` BIGINT(20) NULL DEFAULT NULL,
  `DOUBLE_VAL` DOUBLE NULL DEFAULT NULL,
  `IDENTIFYING` CHAR(1) NOT NULL,
  INDEX `JOB_EXEC_PARAMS_FK` (`JOB_EXECUTION_ID` ASC) VISIBLE,
  CONSTRAINT `JOB_EXEC_PARAMS_FK`
    FOREIGN KEY (`JOB_EXECUTION_ID`)
    REFERENCES `s08p31c201`.`batch_job_execution` (`JOB_EXECUTION_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_execution_seq`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_execution_seq` (
  `ID` BIGINT(20) NOT NULL,
  `UNIQUE_KEY` CHAR(1) NOT NULL,
  UNIQUE INDEX `UNIQUE_KEY_UN` (`UNIQUE_KEY` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_job_seq`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_job_seq` (
  `ID` BIGINT(20) NOT NULL,
  `UNIQUE_KEY` CHAR(1) NOT NULL,
  UNIQUE INDEX `UNIQUE_KEY_UN` (`UNIQUE_KEY` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_step_execution`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_step_execution` (
  `STEP_EXECUTION_ID` BIGINT(20) NOT NULL,
  `VERSION` BIGINT(20) NOT NULL,
  `STEP_NAME` VARCHAR(100) NOT NULL,
  `JOB_EXECUTION_ID` BIGINT(20) NOT NULL,
  `START_TIME` DATETIME NOT NULL,
  `END_TIME` DATETIME NULL DEFAULT NULL,
  `STATUS` VARCHAR(10) NULL DEFAULT NULL,
  `COMMIT_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `READ_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `FILTER_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `READ_SKIP_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `WRITE_SKIP_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `PROCESS_SKIP_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `ROLLBACK_COUNT` BIGINT(20) NULL DEFAULT NULL,
  `EXIT_CODE` VARCHAR(2500) NULL DEFAULT NULL,
  `EXIT_MESSAGE` VARCHAR(2500) NULL DEFAULT NULL,
  `LAST_UPDATED` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  INDEX `JOB_EXEC_STEP_FK` (`JOB_EXECUTION_ID` ASC) VISIBLE,
  CONSTRAINT `JOB_EXEC_STEP_FK`
    FOREIGN KEY (`JOB_EXECUTION_ID`)
    REFERENCES `s08p31c201`.`batch_job_execution` (`JOB_EXECUTION_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_step_execution_context`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_step_execution_context` (
  `STEP_EXECUTION_ID` BIGINT(20) NOT NULL,
  `SHORT_CONTEXT` VARCHAR(2500) NOT NULL,
  `SERIALIZED_CONTEXT` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  CONSTRAINT `STEP_EXEC_CTX_FK`
    FOREIGN KEY (`STEP_EXECUTION_ID`)
    REFERENCES `s08p31c201`.`batch_step_execution` (`STEP_EXECUTION_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`batch_step_execution_seq`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`batch_step_execution_seq` (
  `ID` BIGINT(20) NOT NULL,
  `UNIQUE_KEY` CHAR(1) NOT NULL,
  UNIQUE INDEX `UNIQUE_KEY_UN` (`UNIQUE_KEY` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`book`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`book` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `aladin_url` VARCHAR(200) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `cover_image_url` VARCHAR(200) NULL DEFAULT NULL,
  `description` VARCHAR(1000) NULL DEFAULT NULL,
  `isbn` VARCHAR(40) NOT NULL,
  `page` INT(11) NULL DEFAULT NULL,
  `price` INT(11) NOT NULL,
  `publish_date` DATE NULL DEFAULT NULL,
  `publisher` VARCHAR(50) NULL DEFAULT NULL,
  `review_count` INT(11) NULL DEFAULT 0,
  `score_sum` INT(11) NULL DEFAULT 0,
  `title` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 316882657
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`user` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `kakao_id` BIGINT(20) NULL DEFAULT NULL,
  `nickname` VARCHAR(100) NULL DEFAULT NULL,
  `phone` VARCHAR(100) NULL DEFAULT NULL,
  `profile_url` VARCHAR(200) NULL DEFAULT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 116
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`notification`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`notification` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `upper_limt` INT(11) NULL DEFAULT NULL,
  `book_id` BIGINT(20) NULL DEFAULT NULL,
  `user_id` BIGINT(20) NULL DEFAULT NULL,
  `notification_type` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKcd63rxqpw244o20e5xn64yj0` (`book_id` ASC) VISIBLE,
  INDEX `FKb0yvoep4h4k92ipon31wmdf7e` (`user_id` ASC) VISIBLE,
  CONSTRAINT `FKb0yvoep4h4k92ipon31wmdf7e`
    FOREIGN KEY (`user_id`)
    REFERENCES `s08p31c201`.`user` (`id`),
  CONSTRAINT `FKcd63rxqpw244o20e5xn64yj0`
    FOREIGN KEY (`book_id`)
    REFERENCES `s08p31c201`.`book` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`painting`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`painting` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `file_url` VARCHAR(200) NOT NULL,
  `title` VARCHAR(100) NOT NULL,
  `type` VARCHAR(255) NOT NULL,
  `user_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK75lf3emkpnahkfe6r86ki9325` (`user_id` ASC) VISIBLE,
  CONSTRAINT `FK75lf3emkpnahkfe6r86ki9325`
    FOREIGN KEY (`user_id`)
    REFERENCES `s08p31c201`.`user` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 138
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`review`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`review` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `content` VARCHAR(1000) NOT NULL,
  `score` INT(11) NOT NULL,
  `book_id` BIGINT(20) NULL DEFAULT NULL,
  `user_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK70yrt09r4r54tcgkrwbeqenbs` (`book_id` ASC) VISIBLE,
  INDEX `FKiyf57dy48lyiftdrf7y87rnxi` (`user_id` ASC) VISIBLE,
  CONSTRAINT `FK70yrt09r4r54tcgkrwbeqenbs`
    FOREIGN KEY (`book_id`)
    REFERENCES `s08p31c201`.`book` (`id`),
  CONSTRAINT `FKiyf57dy48lyiftdrf7y87rnxi`
    FOREIGN KEY (`user_id`)
    REFERENCES `s08p31c201`.`user` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 65
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


-- -----------------------------------------------------
-- Table `s08p31c201`.`story`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `s08p31c201`.`story` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME(6) NULL DEFAULT NULL,
  `updated_at` DATETIME(6) NULL DEFAULT NULL,
  `content` VARCHAR(1500) NOT NULL,
  `img_url` VARCHAR(200) NOT NULL,
  `title` VARCHAR(500) NOT NULL,
  `user_id` BIGINT(20) NULL DEFAULT NULL,
  `voice_url` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKisa0vjg7u7066r4phxuniy6kh` (`user_id` ASC) VISIBLE,
  CONSTRAINT `FKisa0vjg7u7066r4phxuniy6kh`
    FOREIGN KEY (`user_id`)
    REFERENCES `s08p31c201`.`user` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 51
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_bin;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
